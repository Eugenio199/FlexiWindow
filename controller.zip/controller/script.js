// State variables
let currentState = "CLOSED";
let currentPercent = 0;
let isMoving = false;

function controlWindow(action) {
  if (isMoving) return;

  const windowStateEl = document.getElementById("windowState");
  const windowPercentEl = document.getElementById("windowPercent");
  const progressBarEl = document.getElementById("progressBar");

  if (action === "OPEN") {
    if (currentPercent === 100) return;
    isMoving = true;
    windowStateEl.innerText = "OPENING...";

    // Simulate window opening movement
    let interval = setInterval(() => {
      if (currentPercent < 100) {
        currentPercent += 20;
        windowPercentEl.innerText = currentPercent + "% Open";
        progressBarEl.style.width = currentPercent + "%";
      } else {
        clearInterval(interval);
        currentState = "OPEN";
        windowStateEl.innerText = "OPEN";
        isMoving = false;
      }
    }, 300);

  } else if (action === "CLOSE") {
    if (currentPercent === 0) return;
    isMoving = true;
    windowStateEl.innerText = "CLOSING...";

    // Simulate window closing movement
    let interval = setInterval(() => {
      if (currentPercent > 0) {
        currentPercent -= 20;
        windowPercentEl.innerText = currentPercent + "% Open";
        progressBarEl.style.width = currentPercent + "%";
      } else {
        clearInterval(interval);
        currentState = "CLOSED";
        windowStateEl.innerText = "CLOSED";
        isMoving = false;
      }
    }, 300);
  }
}